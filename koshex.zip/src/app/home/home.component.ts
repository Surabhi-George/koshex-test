import { Component, OnInit } from '@angular/core';
import * as echarts from 'echarts';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
    options: any;

    constructor() { }

    ngOnInit(): void {

        const yData = [150, 400, 750, 450, 170, 400, 750, 1500, 550, 290,400,90];
        const xData = [28,32,36,40,44,48,52,56,60,70,80,90];


        var path = ['','assets/img/c_house.png','','','assets/img/c_kids.png','','','assets/img/c_beach.png','assets/img/c_kids.png','','assets/img/c_hospital.png',''];

        this.options = {
            tooltip: {
                trigger: 'axis',
                position: function (pt) {
                    return [pt[0], '10%'];
                }
            },
            title: {
                left: 'center',
                text: '',
            },
            responsive: true,
            grid: {
                left: 50,
                right: 50
            },
            toolbox: {
                show: false
            },
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: xData
                }
            ],
            yAxis:{
                splitLine: {
                    lineStyle: {
                        type: 'dashed'
                    }
                }
            },
            dataZoom: [{
                type: 'inside',
                start: 0,
                end: 100
            }, {
                start: 0,
                end: 10
            }],
            series: [
                {
                    name: '',
                    type: 'line',
                    sampling: 'lttb',
                    // symbol: 'circle' ,
                    symbol: function(yData,params){
                        if(path[params.dataIndex] == '' || path[params.dataIndex] == "undefined"){
                            
                        }else{
                            var d = 'image://' + path[params.dataIndex];                   
                            return d;
                        }                        
                    },
                    symbolSize: function(yData,params){
                        if(path[params.dataIndex] == '' || path[params.dataIndex] == "undefined"){
                            return 10;
                        }else{
                            return 33;
                        }                        
                    },
                    smooth: true,
                    // symbolSize: 25,
                    itemStyle: {
                        color: '#3366ff'
                    },
                    areaStyle: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: '#95bbff'
                        }, {
                            offset: 1,
                            color: 'rgba(92, 133, 255, 0)'
                        }])
                    },
                    data: yData,
                    label: {
                        show: false,
                        position: 'top',
                        color: "black",
                        fontSize: 12
                    }
                },
            
            ],
            animationEasing: 'elasticOut',
            animationDelayUpdate: (idx) => idx * 5,
        }
        
    }

    kData = {
        retireAt: 60,
        financialEnd: 90,
        netWorth: 14.2
    }
    events =[
        {
        name: 'House',
        image: 'house.png'
        },
        {
        name: 'Education',
        image: 'education.png'
        },
        {
        name: 'Family',
        image: 'family.png'
        },
        {
        name: 'Vacation',
        image: 'vacation.png'
        },
        {
        name: 'Vehicle',
        image: 'vehicle.png'
        },
        {
        name: 'Startup',
        image: 'startup.png'
        },
        {
        name: 'Gadget',
        image: 'gadget.png'
        },
        {
        name: 'Charity',
        image: 'charity.png'
        },
        {
        name: 'Custom',
        image: 'custom.png'
        }
    ]
    todo = [
        'Get to work',
        'Pick up groceries',
        'Go home',
        'Fall asleep'
    ];

    done = [
        'Get up',
        'Brush teeth',
        'Take a shower',
        'Check e-mail',
        'Walk dog'
    ];

    drop(event: CdkDragDrop<string[]>) {
        alert('kkk')
        if (event.previousContainer === event.container) {
            alert('kk');
          moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
        } else {
            alert('kkk');
          transferArrayItem(event.previousContainer.data,
                            event.container.data,
                            event.previousIndex,
                            event.currentIndex);
        }
    }



    
 
}



